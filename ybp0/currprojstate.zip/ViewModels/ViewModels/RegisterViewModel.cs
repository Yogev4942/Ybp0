﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace ViewModels.ViewModels
{
    public class RegisterViewModel : BaseViewModel
    {
        private readonly IDatabaseService _databaseService;
        private readonly INavigationService _navigationService;

        
        private string _username;
        private string _email;
        private string _password;
        private string _errorMessage;

        public string Username { get => _username; set => SetProperty(ref _username, value); }
        public string Email { get => _email; set => SetProperty(ref _email, value); }
        public string Password { get => _password; set => SetProperty(ref _password, value); }
        public string ErrorMsg { get => _errorMessage; set => SetProperty(ref _errorMessage, value); }

        public RegisterViewModel(IDatabaseService databaseService, INavigationService navigationService)
        {
            this._databaseService = databaseService;
            this._navigationService = navigationService;
            GoBackCommand = new RelayCommand(_ => _navigationService.GoBack());
            RegisterCommand = new RelayCommand(_ => Register());
        }
        public ICommand RegisterCommand { get; private set; }
        public ICommand GoBackCommand { get; private set; }

        public bool Register()
        {
            if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrWhiteSpace(Password) || string.IsNullOrWhiteSpace(Email))
            {
                ErrorMsg = "Fill out all fields";

                return false;
            }
            if (_databaseService.UserExist(Username,Email))
            {
                ErrorMsg = "Username or email exists";
                return false;
            }
            try
            {
                ErrorMsg = string.Empty;
                if (_databaseService.RegisterUser(Username,Email,Password))
                {
                    GoBackCommand.Execute(null);
                }
                else
                {
                    ErrorMsg = "Error Creating user";
                    return false;
                }
            }
            catch (Exception ex)
            {
                ErrorMsg = $"Register error: {ex.Message}";
                // For debugging - keep in output window
                System.Diagnostics.Debug.WriteLine($"Register error: {ex}");
                return false;
            }
            return true;
        }
    }
}
